class AppConstants {

  static const String appName = "demo";
  static const String next = "next";
  static const String signup = "Signup";
  static const String email = "email";
  static const String firstName = "First Name";
  static const String phoneNumber = "Phone Number";

}